# Package description
A collection of helper functions to process videos.
# Welcome to videotools!
